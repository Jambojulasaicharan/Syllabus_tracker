import { useState, useRef, useEffect } from 'react'
import TopicItem from './TopicItem'
import styles from './UnitSection.module.css'

export default function UnitSection({
  unit,
  subjectId,
  onAddTopic,
  onUpdateTopicStatus,
  onDeleteTopic,
  onDeleteUnit
}) {
  const [newTopic, setNewTopic] = useState('')
  const [isExpanded, setIsExpanded] = useState(true)
  const inputRef = useRef(null)

  const topics = unit.topics || []
  const completed = topics.filter(t => t.status === 'Completed').length
  const inProgress = topics.filter(t => t.status === 'In Progress').length
  const notStarted = topics.filter(t => t.status === 'Not Started').length
  const total = topics.length
  const progress = total > 0 ? Math.round((completed / total) * 100) : 0

  function addTopic() {
    const title = newTopic.trim()
    if (!title) return
    onAddTopic(subjectId, unit.id, title)
    setNewTopic('')
    inputRef.current?.focus()
  }

  function handleKeyDown(e) {
    if (e.key === 'Enter') addTopic()
  }

  return (
    <div className={styles.unitSection}>
      {/* Unit Header */}
      <div className={styles.unitHeader}>
        <button
          className={styles.expandBtn}
          onClick={() => setIsExpanded(!isExpanded)}
          title={isExpanded ? 'Collapse unit' : 'Expand unit'}
        >
          {isExpanded ? '▼' : '▶'}
        </button>
        <h3 className={styles.unitTitle}>{unit.title}</h3>
        <div className={styles.unitStats}>
          {total > 0 && (
            <>
              <span className={styles.stat} title="Completed topics">
                <span className={styles.statColor} style={{ background: 'var(--success)' }} />
                {completed}
              </span>
              <span className={styles.stat} title="In Progress topics">
                <span className={styles.statColor} style={{ background: 'var(--warning)' }} />
                {inProgress}
              </span>
              <span className={styles.stat} title="Not Started topics">
                <span className={styles.statColor} style={{ background: 'var(--border)' }} />
                {notStarted}
              </span>
              <span className={styles.progressLabel}>{progress}%</span>
            </>
          )}
        </div>
        {total > 0 && (
          <div className={styles.progressBar}>
            <div
              className={styles.progressFill}
              style={{ width: `${progress}%` }}
            />
          </div>
        )}
        <button
          className={styles.deleteUnitBtn}
          onClick={() => onDeleteUnit(subjectId, unit.id)}
          title="Delete unit"
        >
          ×
        </button>
      </div>

      {/* Unit Content */}
      {isExpanded && (
        <div className={styles.unitContent}>
          {/* Add Topic Input */}
          <div className={styles.addTopicWrap}>
            <input
              ref={inputRef}
              className={styles.addTopicInput}
              type="text"
              placeholder="Add a new topic..."
              value={newTopic}
              onChange={e => setNewTopic(e.target.value)}
              onKeyDown={handleKeyDown}
            />
            <button
              className={styles.addTopicBtn}
              onClick={addTopic}
              disabled={!newTopic.trim()}
              title="Add topic"
            >
              +
            </button>
          </div>

          {/* Topics List */}
          {topics.length === 0 ? (
            <div className={styles.emptyUnit}>
              <p>No topics yet. Add one above to get started!</p>
            </div>
          ) : (
            <div className={styles.topicsList}>
              {topics.map((topic, idx) => (
                <TopicItem
                  key={topic.id}
                  topic={topic}
                  index={idx}
                  onStatusChange={(newStatus) =>
                    onUpdateTopicStatus(subjectId, unit.id, topic.id, newStatus)
                  }
                  onDelete={() => onDeleteTopic(subjectId, unit.id, topic.id)}
                />
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  )
}
